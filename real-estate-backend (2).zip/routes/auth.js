import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { pool } from "../db.js";

const router = express.Router();

// Registrazione agenzia + utente admin
router.post("/register", async (req, res) => {
  const { nome, email, password } = req.body;
  if (!nome || !email || !password) return res.status(400).json({ error: "Dati mancanti" });

  try {
    const hashed = await bcrypt.hash(password, 10);
    const ag = await pool.query("INSERT INTO agenzie (nome) VALUES ($1) RETURNING id", [nome]);
    const user = await pool.query(
      `INSERT INTO utenti (nome, email, password_hash, ruolo, agenzia_id)
       VALUES ($1,$2,$3,'admin_agenzia',$4) RETURNING id,agenzia_id,ruolo`,
      [nome, email, hashed, ag.rows[0].id]
    );

    const token = jwt.sign(
      { id: user.rows[0].id, agenzia_id: user.rows[0].agenzia_id, ruolo: user.rows[0].ruolo },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Errore registrazione" });
  }
});

// Login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Dati mancanti" });

  try {
    const result = await pool.query("SELECT * FROM utenti WHERE email=$1", [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: "Credenziali non valide" });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Credenziali non valide" });

    const token = jwt.sign(
      { id: user.id, agenzia_id: user.agenzia_id, ruolo: user.ruolo },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Errore login" });
  }
});

export default router;
