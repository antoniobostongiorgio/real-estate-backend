import express from "express";
import { pool } from "../db.js";
import { authMiddleware } from "../middleware/auth.js";

const router = express.Router();

// Lista annunci
router.get("/", authMiddleware, async (req, res) => {
  try {
    const r = await pool.query(
      "SELECT * FROM annunci WHERE agenzia_id=$1 ORDER BY created_at DESC",
      [req.user.agenzia_id]
    );
    res.json(r.rows);
  } catch (e) {
    res.status(500).json({ error: "Errore lettura annunci" });
  }
});

// Creazione annuncio
router.post("/", authMiddleware, async (req, res) => {
  const { titolo, descrizione, prezzo, mq, locali, bagni, indirizzo } = req.body;
  if (!titolo || !prezzo || !mq || !locali || !bagni) return res.status(400).json({ error: "Campi obbligatori mancanti" });

  try {
    const r = await pool.query(
      `INSERT INTO annunci (agenzia_id, titolo, descrizione, prezzo, mq, locali, bagni, indirizzo)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user.agenzia_id, titolo, descrizione || "", prezzo, mq, locali, bagni, indirizzo || ""]
    );
    res.json(r.rows[0]);
  } catch (e) {
    res.status(500).json({ error: "Errore creazione annuncio" });
  }
});

export default router;
